package jpabook.jpashop.domain;

public enum DelivertStatus {

}
